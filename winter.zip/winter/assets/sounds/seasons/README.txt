Place your .ogg files here with these exact names:
- spring.ogg
- summer.ogg
- autumn.ogg
- winter.ogg

Folder:
resourcepack/assets/seasons/sounds/
